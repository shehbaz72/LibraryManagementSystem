<!-- Start Left menu area -->
<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index.php"><img class="main-logo" src="assets/img/logo/logo.png" alt="" /></a>
                <strong><a href="index.php"><img src="assets/img/logo/logosn.png" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            
                        <li>
                            <a class="has-arrow"  aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Users</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="" href="index.php?file=users"><span class="mini-sub-pro">All Users</span></a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a class="has-arrow" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Books</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="" href="index.php?file=categories"><span class="mini-sub-pro">Categories</span></a></li>
                                <li><a title="" href="index.php?file=authors"><span class="mini-sub-pro">Authors</span></a></li>
                                <li><a title="" href="index.php?file=books"><span class="mini-sub-pro">Books List</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Issue Books</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Peity Charts" href="index.php?file=issuenewbook"><span class="mini-sub-pro">Issue New Book</span></a></li>
                                <li><a title="Data Table" href="index.php?file=manageissuebooks"><span class="mini-sub-pro">Manage Issue Books </span></a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a class="has-arrow" aria-expanded="false" href="index.php?file=logout"></span><i class="fa fa-sign-out" style="font-size:24px;color:red"></i><span class="mini-click-non text-danger"> Sign Out</span></a>
                            
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>