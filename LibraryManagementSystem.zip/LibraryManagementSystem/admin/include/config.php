<?php

define('css','assets/css/');
define('img','assets/img/');
define('js','assets/js/');

define('acss','admin/assets/css/');
define('aimg','admin/assets/img/');
define('ajs','admin/assets/js/');

?>