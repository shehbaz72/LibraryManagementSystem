<?php
$conn = mysqli_connect('localhost', 'root', '', 'librarymanagementsystem');
if (!$conn) {
    echo "connection error";
} 
?>