-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2019 at 06:10 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarymanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `adminemail` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `adminemail`, `username`, `password`, `updationdate`) VALUES
(1, 'admin', 'jarvisapollo23@gmail.com', 'admin', 'admin', '2019-01-18 01:52:59');

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `id` int(11) NOT NULL,
  `authorname` varchar(255) NOT NULL,
  `creationdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `authorname`, `creationdate`) VALUES
(1, 'p bkji', '2019-01-10'),
(2, 'm jhun', '2019-01-10'),
(4, 'z cldr', '2019-01-10'),
(5, 'n jhuer', '2019-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `bookname` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `isbn` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `regdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `bookname`, `category`, `author`, `isbn`, `price`, `regdate`) VALUES
(1, 'book 1', '1', '2', 7878, '89.00', '2019-01-10'),
(2, 'ytijk kjkl', '3', '1', 56567, '99', '2019-01-10'),
(3, 'klmmn jhjn', '3', '1', 8998, '149', '2019-01-10'),
(5, 'ieruif roikj', '3', '4', 87880, '149', '2019-01-10'),
(6, 'ekd ekfl', '3', '2', 9878670, '299', '2019-01-10'),
(7, 'bvure cnm', '6', '5', 863493, '199', '2019-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` enum('active','inactive','','') NOT NULL,
  `creationdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `status`, `creationdate`) VALUES
(1, 'test1', 'active', '2019-01-10'),
(2, 'test', 'inactive', '2019-01-10'),
(3, 'butj', 'active', '2019-01-10'),
(4, 'tyukkm', 'active', '2019-01-10'),
(5, 'dfkdm', 'inactive', '2019-01-10'),
(6, 'cttr', 'active', '2019-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `issuedbooks`
--

CREATE TABLE `issuedbooks` (
  `id` int(11) NOT NULL,
  `bookid` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `issuedate` date NOT NULL,
  `returndate` date DEFAULT NULL,
  `returnstatus` enum('0','1','','') NOT NULL DEFAULT '0',
  `fine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issuedbooks`
--

INSERT INTO `issuedbooks` (`id`, `bookid`, `email`, `issuedate`, `returndate`, `returnstatus`, `fine`) VALUES
(1, 1, 'pqr@gmail.com', '2019-01-10', '2019-01-10', '1', 0),
(2, 2, 'abc@gmail.com', '2019-01-10', '2019-01-10', '1', 0),
(3, 3, 'ytldmc@gmail.com', '2019-01-10', NULL, '0', NULL),
(4, 3, 'ytldmc@gmail.com', '2019-01-10', '2019-01-10', '1', 50),
(5, 2, 'iuwui@gmail.com', '2019-01-10', '2019-01-12', '1', 20),
(6, 6, 'pqr@gmail.com', '2019-01-11', '2019-01-12', '1', 0),
(7, 5, 'pqr@gmail.com', '2019-01-12', NULL, '0', NULL),
(8, 7, 'mb@gmail.com', '2019-01-12', '2019-01-12', '1', 1),
(9, 5, 'lkfcld@gmail.com', '2019-01-12', NULL, '0', NULL),
(10, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 0),
(11, 3, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 0),
(12, 3, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(13, 3, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 50),
(14, 5, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(15, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(16, 5, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 0),
(17, 5, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(18, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(19, 1, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-19', '1', 78),
(20, 3, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(21, 5, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(22, 1, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 0),
(23, 1, 'pqr@gmail.com', '2019-01-12', '2019-01-18', '1', 0),
(24, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(25, 7, 'abc@gmail.com', '2019-01-12', NULL, '0', NULL),
(26, 3, 'shehbaz.badi572@gmail.com', '2019-01-12', '2019-01-12', '1', 0),
(27, 2, 'pqr@gmail.com', '2019-01-12', '2019-01-19', '1', 89),
(28, 7, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(29, 1, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(30, 5, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(31, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(32, 6, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL),
(33, 1, 'shehbaz.badi572@gmail.com', '2019-01-12', NULL, '0', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` int(10) NOT NULL,
  `regdate` date NOT NULL,
  `status` enum('active','inactive','','') NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `mobile`, `regdate`, `status`, `password`) VALUES
(1, 'abc', 'xyz', 'abc@gmail.com', 8787890, '2019-01-10', 'active', 'abc1'),
(2, 'pqr', 'mno', 'pqr@gmail.com', 7989009, '2019-01-10', 'active', 'pqr1'),
(3, 'ytefy', 'jdk', 'ytldmc@gmail.com', 878989, '2019-01-10', 'inactive', 'ytre'),
(4, 'djfcdk', 'dfkdf', 'lkfcld@gmail.com', 84758, '2019-01-10', 'active', 'abc111'),
(5, 'uefui', 'ksjdk', 'iuwui@gmail.com', 899898, '2019-01-10', 'inactive', 'qweac'),
(6, 'test', 'sss', 'test@gmail.com', 9869090, '2019-01-11', 'active', 'test'),
(7, 'mjunhy', 'bhuijn', 'mb@gmail.com', 978790, '2019-01-12', 'inactive', '0000'),
(8, 'jdjkj', 'ifjk', 'shehbaz.badi572@gmail.com', 87487, '2019-01-12', 'active', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issuedbooks`
--
ALTER TABLE `issuedbooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `issuedbooks`
--
ALTER TABLE `issuedbooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
