<?php
session_destroy();
?>
<script>
    window.location.replace("index.php");
</script>
?>