<!-- Start Left menu area -->
<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index.php"><img class="main-logo" src="../admin/assets/img/logo/logo.png" alt="" /></a>
                <strong><a href="index.php"><img src="../admin/assets/img/logo/logosn.png" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                        
                        <li>
                            <a class="has-arrow" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Books</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="" href="index.php?file=books"><span class="mini-sub-pro">Books List</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" aria-expanded="false"><span class="educate-icon educate-data-table icon-wrap"></span> <span class="mini-click-non">Issue Books</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Peity Charts" href="index.php?file=issuedbooks"><span class="mini-sub-pro">Issued Book</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" aria-expanded="false"></span><i class="glyphicon glyphicon-cog" style="font-size:24px"></i><span class="mini-sub-pror"> Setting</span></a>  
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Peity Charts" href="index.php?file=changepass"><span class="mini-sub-pro">Change Password</span></a></li>
                            </ul> 
                        </li>
                        <li>
                            <a class="has-arrow" aria-expanded="false" href="index.php?file=about"></span><i class="fa fa-info-circle" style="font-size:24px;"></i><span class="mini-sub-pror">About Us</span></a>   
                        </li>        
                        <li>
                            <a class="has-arrow" aria-expanded="false" href="index.php?file=contact"></span><i class="fa fa-envelope" style="font-size:24px;"></i><span class="mini-sub-pror">Contact Us</span></a>   
                        </li>
                        <li>
                            <a class="has-arrow" aria-expanded="false" href="index.php?file=logout"></span><i class="fa fa-sign-out" style="font-size:24px;color:red"></i><span class="text-danger"> Sign Out</span></a>   
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>