<?php

define('css','../admin/assets/css/');
define('img','../admin/assets/img/');
define('js','../admin/assets/js/');

?>