<div class="container">
    <div class="col-md-10">
        <div class="">
            <h3>About Us</h3>
        </div>
        <p><i>&nbsp; &nbsp; &nbsp; Our is one of the best place where you can relax and read books, magazines,news papers from wide collection of almost 1.5 lac books in 3 languages,Gujarati-Hindi-English, covering all subjects from Science,Literature,Art,History,Religion,Biography, Travel and the list is never ending. Offering one of the best collection in Gujarat.</i></p>

        <div><br>
            <h4>Contact Details</h4>
            <p><b>E-Mail: </b>jarvisapollo23@gmail.com <br>
            <b>Contact No.: </b>079 263872 <br>
            <b>Address: </b> State Central Library, Sector 17, Gandhinagar 382017.<br>
            </p>
        </div>

        <div>
            <b><u><a href="index.php?file=contact">Contact Us</a></u></b>
        </div>
<br>
        <div>
            <hr>
            <p ><i>&nbsp; &nbsp; &nbsp; "The library card is a passport to wonders and miracles, glimpses into other lives, religions, experiences, the hopes and dreams and strivings of ALL human beings, and it is this passport that opens our eyes and hearts to the world beyond our front doors, that is one of our best hopes against tyranny, xenophobia, hopelessness, despair, anarchy, and ignorance."</i></p>
            <hr>
        </div>
    </div>
</div>